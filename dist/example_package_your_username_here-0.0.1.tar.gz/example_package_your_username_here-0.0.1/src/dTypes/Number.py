class Number:
    def __init__(self, key: str, value: int):
        self.key = key
        self.value = value

    def __init__(self, key: str, value: float):
        self.key = key
        self.value = value

    def get(self):
        return self.value

    def set(self, value: int):
        self.value = value