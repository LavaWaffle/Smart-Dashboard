from typing import List, Union, Type
from dTypes import Number
class SmartDashboard:
    dashboardItems: List[Union[int, Type[Number.Number]]] = []

    @staticmethod
    def putNumber(key: str, value: int):
        """
        Add a number to the dashboard
        :param key: The key to use
        :param value: The value to use
        """
        SmartDashboard.__putNumber(key,value)

    @staticmethod
    def putNumber(key: str, value: float):
        """
        Add a number to the dashboard
        :param key: The key to use
        :param value: The value to use
        """
        SmartDashboard.__putNumber(key,value)

    @staticmethod
    def __putNumber(key:str,value):
        if not(type(value) is int or type(value) is float):
            raise TypeError("Value must be of type int or float")
        number = Number(key,value)
        SmartDashboard.dashboardItems.append(number)

    @staticmethod
    def test():
        print(SmartDashboard.dashboardItems)



# import pygame
# pygame.init()

# WIN_WIDTH = 500
# WIN_HEIGHT = 500

# screen = pygame.display.set_mode((WIN_WIDTH, WIN_HEIGHT), pygame.RESIZABLE)
# pygame.display.set_caption('Smart Dashboard')

# def draw_window():
#     screen.fill((102, 102, 102))
#     pygame.display.update()

# running = True
# while running:
#     for event in pygame.event.get():
#         if event.type == pygame.QUIT:
#             running = False
#         if event.type == pygame.VIDEORESIZE:
#             screen = pygame.display.set_mode((event.w, event.h), pygame.RESIZABLE)
#     draw_window()

# pygame.quit()
