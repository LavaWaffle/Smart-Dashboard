import sys
# generate this path by right clicking on the dashboard folder and selecting "Copy Path"
# then paste it here
sys.path.insert(0, r"C:\Users\Anand\Documents\coding\python\SmartDashboard\dashboard")

from src.dashboard import SmartDashboard

import pygame
pygame.init()
WIN_WIDTH = 500
WIN_HEIGHT = 500

win = pygame.display.set_mode((WIN_WIDTH, WIN_HEIGHT))
pygame.display.set_caption('Test Environment')
x = 50
y = 50
width = 50
height = 50
vel = 5

run = True

# pygame clock 30 fps
clock = pygame.time.Clock()


while run:
    SmartDashboard.putNumber("x",x)
    SmartDashboard.putNumber("y",y)
    SmartDashboard.putNumber("vel",vel)
    SmartDashboard.test()
    clock.tick(30)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

    keys = pygame.key.get_pressed()

    if keys[pygame.K_LEFT] and x > vel:
        x -= vel
    if keys[pygame.K_RIGHT] and x < WIN_WIDTH - width - vel:
        x += vel
    if keys[pygame.K_UP] and y > vel:
        y -= vel
    if keys[pygame.K_DOWN] and y < WIN_HEIGHT - height - vel:
        y += vel

    win.fill((102, 102, 102))
    pygame.draw.rect(win, (90, 200, 255), (x, y, width, height))
    pygame.display.update()

pygame.quit()
